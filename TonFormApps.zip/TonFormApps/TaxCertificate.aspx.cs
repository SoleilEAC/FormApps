﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text.RegularExpressions;

namespace TonFormApps
{
    public partial class TaxCertificate : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            //if (!IsPostBack)
            //{
            //  lblMsg.Visible = false;
            //}

        }

        protected void BtnContinue_Click(object sender, EventArgs e)
        {
            DataTable dt;
            string idNum="";
            string nAmount = " ";

            if(!ValidateData())
            {
                //Response.Write("<script language='javascript'>alert('Please fill required fields with valid value!.'); window.close();</script>");
               //lblMsg.Text = "Please fill required fields with valid value!";
                lblMsg.Visible = true;
                // ClientScript.RegisterStartupScript(GetType(), "script", "showMyDialog('" + lblMsg.Text + "','error" + "');", true);
                //this.RegisterClientScriptBlock(typeof(string), "key", string.Format("alert('{0}');", "Please fill required fields with valid value!"), true);
                // this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('" + "Please fill required fields with valid value!" + "');", true);

               


            }
            else
            {
                //lblMsg.Text = " ";
                //lblMsg.Visible = false;
                dt = SQL.Run("select invprice from Inventory where invID =@invID", 8); // Tax Certificate price

                if (dt.Rows.Count > 0)
                    nAmount = dt.Rows[0]["invprice"].ToString();

                dt = SQL.Run("SELECT IDENT_CURRENT('[Formdata]')+1 as ID");

                if (dt.Rows.Count > 0)
                {
                    idNum = dt.Rows[0]["ID"].ToString();


                    SQL sql = new SQL("insert into formdata (requestor,lawfirm,mailingaddr,phone,email,fax, rollnumber, address, purchaser, owners,inv_id_fk, amount,status,date_entered) values (@REQUESTOR, @LAWFIRM, @MAILINGADDR, @PHONE, @EMAIL,@FAX,@ROLLNUMBER,@ADDRESS,@PURCHASER,@OWNERS,@INV_ID_FK, @AMOUNT,@STATUS,@DATE_ENTERED)");
                    sql.AddParameter("@REQUESTOR", Request.Form["fullname"]);
                    sql.AddParameter("@LAWFIRM", Request.Form["firm"]);
                    sql.AddParameter("@MAILINGADDR", Request.Form["mailadd"]);
                    sql.AddParameter("@PHONE", Request.Form["phone"]);
                    sql.AddParameter("@EMAIL", Request.Form["email"]);
                    sql.AddParameter("@FAX", Request.Form["fax"]);
                    sql.AddParameter("@ROLLNUMBER", Request.Form["rollnumber"]);
                    sql.AddParameter("@ADDRESS", Request.Form["address"]);
                    sql.AddParameter("@PURCHASER", Request.Form["purchasername"]);
                    sql.AddParameter("@INV_ID_FK", 8);
                    sql.AddParameter("@OWNERS", Request.Form["owners"]);
                    sql.AddParameter("@AMOUNT", Convert.ToDecimal(nAmount));
                    sql.AddParameter("@STATUS", 1); // 1 - Entered NOT YET PAID
                    sql.AddParameter("@DATE_ENTERED", DateTime.Now);
                    sql.Run();
                }

                log("Tax Certificate Success " + idNum.ToString(), nAmount);

                //            Response.Redirect("Checkout.aspx?nAmount=" + nAmount+"&nProcess=1&form_fk_id="+idNum.ToString());
                Response.Redirect("Checkout.aspx?nProcess=1&form_fk_id=" + idNum.ToString());



            }
        }

        private Boolean  ValidateData()
        {
            Boolean result = false;

         //   Regex regex = new Regex(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-
         //9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$",
         //RegexOptions.CultureInvariant | RegexOptions.Singleline);

            Regex regex=new Regex(@"^(?!\.)(""([^""\r\\]|\\[""\r\\])*""|" + @"([-a-z0-9!#$%&'*+/=?^_`{|}~]|(?<!\.)\.)*)(?<!\.)" + @"@[a-z0-9][\w\.-]*[a-z0-9]\.[a-z][a-z\.]*[a-z]$", RegexOptions.IgnoreCase);

            

            bool isValidEmail = regex.IsMatch(Request.Form["email"]);
          

            if (Request.Form["fullname"] != "" && Request.Form["rollnumber"] != "" && Request.Form["email"] != "")
            {
                if (!isValidEmail)
                {
                    lblMsg.Text = "The email is invalid, please verify.";
                    result = false;
                }
                else
                    result = true;
            }
            else
            {
                lblMsg.Text = "Please fill required fields with valid value!";
                result = false;
            }

            return result;

        }

        public void log(string bn, string bl)
        {
            string ipaddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

            if (ipaddress == "" || ipaddress == null)
                ipaddress = Request.ServerVariables["REMOTE_ADDR"];

            SQL.Run("insert into log values ( @TIMESTAMP,@IP, @BN,@LN)", DateTime.Now, ipaddress, bn, bl);
        }
    }


}