﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TonFormApps
{
    public partial class Bin_Purchase : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            DataTable dt;
            string nAmount = " ";

            dt = SQL.Run("select invprice from Inventory where invID =@invID", 1); // Blue Bin price

            if (dt.Rows.Count > 0)
            {
                nAmount = dt.Rows[0]["invprice"].ToString();
                Lblbb.Text = "How many Blue Bins: ($" + nAmount + " + HST each)";
                inPrA.Text = nAmount;
                //this.ibb = dt.Rows[0]["invprice"].ToDecimal;
            }
            dt = SQL.Run("select invprice from Inventory where invID =@invID", 2); // Green Bin price

            if (dt.Rows.Count > 0)
            {
                nAmount = dt.Rows[0]["invprice"].ToString();
                Lblgb.Text = "How many Green Bins: ($" + nAmount + " + HST each)";
                inPrB.Text = nAmount;
            }
        }

        protected void CalculateAmount()
        {
            

        }
        protected void BtnContinue_Click(object sender, EventArgs e)
        {
        }

    
    }
}