﻿using System.Data;

namespace TonFormApps
{
    public class SQL : Database
    {
        static DatabaseType type = DatabaseType.SQL;
        static string hostServer = "172.16.0.34";
        static string database = "TONApps";
        static string username = "TonForms_Viewer";
        static string password = "Not4everyone!2021";

        public SQL(string str) : base(type, str, hostServer, database, username, password)
        {

        }

        public static new DataTable Run(string str, params object[] list)
        {
            return Run(type, str, hostServer, database, username, password, list);
        }

        new public static string RunString(string str, params object[] list)
        {
            return Run(str, list).Rows[0][0].ToString();
        }
    }
}
