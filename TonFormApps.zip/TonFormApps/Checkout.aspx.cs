﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using net.authorize.sample;
using System.Threading;

namespace TonFormApps
{
    public partial class Checkout : System.Web.UI.Page
    {
        public string bodyDetail = "";
        public string totalAmount = "";
        string dProcess = "0";
        string dID = "";
        string sTransResult = "";
        Boolean bResult = false;


        protected void Page_Load(object sender, EventArgs e)
        {

            dProcess = Request.QueryString["nProcess"];
            dID = Request.QueryString["form_fk_id"];
            TransGrid(dProcess);
            TransIncomplete.Visible = false;
            TransSuccess.Visible = false;
            this.Page.DataBind();

        }

        protected void BtnPayment_Click(object sender, EventArgs e)
        {
            DateTime dToday = DateTime.Now;
            DataTable dt;
            string idNum = "";
            //string content = "window.onload=function(){ alert('";
            Thread.Sleep(3000);

            // Form Update
            if (dProcess == "1")
            {
                if (!ValidateData())
                {
                    // Validate all fields are filled up
                    lblMsg.Visible = true;
                }
                else
                {
                    lblMsg.Visible = false;
                    Core.xID = dID;
                    dt = SQL.Run("SELECT IDENT_CURRENT('Payments]')+1 as ID");

                    if (dt.Rows.Count > 0)
                    {
                        idNum = dt.Rows[0]["ID"].ToString();
                        Core.xIDNum = idNum;
                        ChargeCreditCard.cCTag = Request.Form["cardNumber"];
                        ChargeCreditCard.Month = Request.Form["ccMonth"];
                        ChargeCreditCard.Year = Request.Form["ccYear"];
                        ChargeCreditCard.CV = Request.Form["ccCV"];

                        ChargeCreditCard.Addr = Request.Form["address"];
                        ChargeCreditCard.City = Request.Form["city"];
                        ChargeCreditCard.postalCode = Request.Form["zip"];
                        ChargeCreditCard.cardHolder = Request.Form["card-holder"];

                        // Temporarily removed
                        //ChargeCreditCard.Run(Core.loginID, Core.tranKey, Convert.ToDecimal(totalAmount));

                       // bResult = ChargeCreditCard.xStatusResult;
                       // sTransResult = ChargeCreditCard.xTransResult;


                        bResult = true;
                        sTransResult = "Transaction successful";

                      
                        if (bResult)
                        // Transaction Successful
                        {
                            //try
                            //{
                            //SQL sql = new SQL("insert into Payments (form_fk_id,ccid,nameoncard,status,date_entered,date_processed,total_amount) values (@FORM_FK_ID,@CCID,@NAMEONCARD,@STATUS,@DATE_ENTERED,@DATE_PROCESSED,@TOTAL_AMOUNT)");
                            //sql.AddParameter("@FORM_FK_ID", int.Parse(dID));
                            //sql.AddParameter("@CCID", ChargeCreditCard.xTransResult);
                            //sql.AddParameter("@NAMEONCARD", Request.Form["card-holder"]);
                            //sql.AddParameter("@STATUS", 1);
                            //sql.AddParameter("@DATE_ENTERED", dToday);
                            //sql.AddParameter("@DATE_PROCESSED", dToday);
                            //sql.AddParameter("@TOTAL_AMOUNT", Convert.ToDecimal(totalAmount));
                            //sql.Run();
                            //}
                            try
                            {
                                SQL sql = new SQL("insert into Payments (form_fk_id,ccid,nameoncard,status,date_entered,date_processed,total_amount) values (@FORM_FK_ID,@CCID,@NAMEONCARD,@STATUS,@DATE_ENTERED,@DATE_PROCESSED,@TOTAL_AMOUNT)");
                                sql.AddParameter("@FORM_FK_ID", int.Parse(dID));
                                sql.AddParameter("@CCID", "12345567");
                                sql.AddParameter("@NAMEONCARD", Request.Form["card-holder"]);
                                sql.AddParameter("@STATUS", 1);
                                sql.AddParameter("@DATE_ENTERED", dToday);
                                sql.AddParameter("@DATE_PROCESSED", dToday);
                                sql.AddParameter("@TOTAL_AMOUNT", Convert.ToDecimal(totalAmount));
                                sql.Run();

                                sql = new SQL("update Formdata set payment_id_fk=@id_fk, status=2 where formdata.id=@FORM_FK_ID"); // Status Paid
                                sql.AddParameter("@id_fk", idNum == "" ? 0 : int.Parse(idNum));
                                sql.AddParameter("@FORM_FK_ID", dID == "0" ? 0 : int.Parse(dID));

                                sql.Run();
                            }
                            catch (Exception ex)
                            {
                                log("InsPayment" + ex.ToString().Substring(0,40), totalAmount);
                                throw new Exception(string.Format("(1)Insert Payment: ", ex));
                            }
                           

                            cardDetails.Visible = false;
                            TransIncomplete.Visible = false;
                            TransSuccess.Visible = true;
                            lblSuccess.Text = dID;

                            log("Payment successful TaxCert " + dID, totalAmount);
                            sendConfirmationEmail();
                            //try
                            //{
                            //    sendConfirmationEmail();
                            //}
                            //catch (Exception ex)
                            //{
                            //    log("ConfEmail" + ex.ToString().Substring(0,40), totalAmount);
                            //    throw new Exception(string.Format("(2)Send Confirmation email: ", ex));
                            //}


                            //Response.Redirect(Request.Url.AbsoluteUri); clears form
                            //content += "Your details have been saved" + "');window.location='" + Request.Url.AbsoluteUri+"';}" ;
                            //ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", content, true);
                        }
                        else
                        {
                            cardDetails.Visible = false;
                            TransIncomplete.Visible = true;
                            TransSuccess.Visible = false;
                            log("Payment NOT successful TaxCert " + dID, totalAmount);
                        }
                    }

                }
            }
        }

        private void TransGrid(string typeProcess)

        {
            DataTable dt;

            totalAmount = "0";
            if (typeProcess == "1")
            {
                // Formdata -- Tax Certificate
                dt = SQL.Run(" select b.invdesc, b.shortname,a.amount, 1 as unit from Formdata a LEFT JOIN Inventory b on b.invid = a.inv_id_fk where a.id =  @dID", dID); // Tax Certificate request

                if (dt.Rows.Count > 0)
                {
                    bodyDetail = "<h3 class=\"title\">Checkout</h3> " +
                                "<div class=\"item\">" +
                                "  <span class=\"price\">" + dt.Rows[0]["amount"].ToString() + "</span>" +
                                "<p class=\"item-description\">" + dt.Rows[0]["invdesc"].ToString() + "</p>" +
                                "</div>" +
                                "<div class=\"total\">Total<span class=\"price\">" + dt.Rows[0]["amount"].ToString() + "</span></div>";

                    totalAmount = dt.Rows[0]["amount"].ToString();
                }


            }



        }
        protected void BtnContinue_Click(object sender, EventArgs e)
        {
            productDetails.Visible = true;
            cardDetails.Visible = true;
            TransSuccess.Visible = false;
            Page.Response.Redirect(Page.Request.Url.ToString(), true);// refreshes page
        }

        //protected void BtnComplete_Click(object sender, EventArgs e)
        //{
        //    productDetails.Visible = false;
        //    TransSuccess.Visible = false;
        //    cardDetails.Visible = false;

        //}

        protected void sendConfirmationEmail()
        {
            DataTable dt;
            string content = "";
            string email = "";


            dt = SQL.Run("select requestor,lawfirm,mailingaddr,phone,email,fax,rollnumber,address,purchaser,owners FROM [Formdata] where id =@dID", dID); // Tax Certificate request

            if (dt.Rows.Count > 0)
            {
                email = dt.Rows[0]["email"].ToString();
                content += "<b>Tax Certificate Request Form has a new response.</b>";
                content += Environment.NewLine;
                content += Environment.NewLine + DateTime.Now.ToString("D");
                content += Environment.NewLine + "<b>Full Name of Lawyer/ Requestor:</b> " + dt.Rows[0]["requestor"].ToString();
                content += Environment.NewLine + "<b>Name of Law Firm:</b> " + dt.Rows[0]["lawfirm"].ToString();
                content += Environment.NewLine + "<b>Mailing address:</b> " + dt.Rows[0]["mailingaddr"].ToString();
                content += Environment.NewLine + "<b>Phone Number:</b> " + dt.Rows[0]["phone"].ToString();
                content += Environment.NewLine + "<b>Email Address:</b> " + dt.Rows[0]["email"].ToString();
                content += Environment.NewLine + "<b>Fax Number:</b> " + dt.Rows[0]["fax"].ToString();
                content += Environment.NewLine;
                content += Environment.NewLine + "<b>Property Information</b>";
                content += Environment.NewLine;

                content += Environment.NewLine + "<b>Property Tax Roll Number:</b> " + dt.Rows[0]["rollnumber"].ToString();
                content += Environment.NewLine + "<b>Property Address:</b> " + dt.Rows[0]["address"].ToString();
                content += Environment.NewLine + "<b>Purchaser Name(s):</b> " + dt.Rows[0]["purchaser"].ToString();
                content += Environment.NewLine + "<b>Name(s) of current owner(s):</b> " + dt.Rows[0]["owners"].ToString();
                content += Environment.NewLine + "<b>Certificate Request ID:</b> " + dID;
                content += Environment.NewLine;
                content += Environment.NewLine + "<b>Payment ID:</b> " + sTransResult;

                // Core.sendMail(email, "Tax Certificate Request", content, "paymentnotification@newmarket.ca", "paymentnotification", "Love2help");
                Core.sendMail(email, "Tax Certificate Request", content);
                // Core.log(Name, "E-mail success", "SUCCESS - Vendor #" + vendorNumber + ", " + email);
                log("Tax Certificate email success " + dID, totalAmount);

            }
        }
        public void log(string bn, string bl)
        {
            string ipaddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

            if (ipaddress == "" || ipaddress == null)
                ipaddress = Request.ServerVariables["REMOTE_ADDR"];

            SQL.Run("insert into log values ( @TIMESTAMP,@IP, @BN,@LN)", DateTime.Now, ipaddress, bn, bl);
        }

        private Boolean ValidateData()
        {
            Boolean result = false;
            lblMsg.Text = "";

            if (Request.Form["card-holder"] != "" && Request.Form["cardnumber"] != "" && Request.Form["ccMonth"] != "" && Request.Form["ccYear"] != "" && Request.Form["ccCV"] != "" && Request.Form["ccYear"] != "" && Request.Form["address"] != "" && Request.Form["city"] != "" && Request.Form["zip"] != "")
            {
                    result = true;
                
            }
            else
            {
                lblMsg.Text = "Please fill required fields with valid value!";
                result = false;
            }
            return result;

        }

    }

}