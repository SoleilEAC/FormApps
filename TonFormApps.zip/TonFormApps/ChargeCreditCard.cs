﻿using System;
using System.Linq;
using System.Data;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using AuthorizeNet.Api.Controllers;
using AuthorizeNet.Api.Contracts.V1;
using AuthorizeNet.Api.Controllers.Bases;



namespace net.authorize.sample
{
    
    public class ChargeCreditCard
    {
        private static string _cCTag="";
        private static string _Month = "";
        private static string _Year = "";
        private static string _CV = "";
        private static string _addr = "";
        private static string _city = "";
        private static string _postalc = "";

        private static string _cardHolder = "";

        private static string _xTransResult = "";
        private static Boolean _xStatusResult = false;

        public static string xTransResult
        {
            get { return _xTransResult; } set { _xTransResult = value; }
        }
        public static Boolean xStatusResult
        {
            get { return _xStatusResult; }set { _xStatusResult = value; }
        }
        public static string cCTag
        {
            get {return _cCTag;}set{_cCTag = value;}
        }

        public static string Month
        {
            get{return _Month;} set {_Month = value;}
        }

        public static string Year
        {
            get { return _Year; } set{_Year = value;}
        }
        public static string CV
        {
            get{ return _CV; } set {_CV = value;}
        }

        public static string cardHolder
        {
            get { return _cardHolder; }
            set { _cardHolder = value; }
        }

       

        public static string Addr
        {
            get { return _addr; }
            set { _addr = value; }
        }

        public static string City
        {
            get { return _city; }
            set { _city = value; }
        }
        public static string postalCode
        {
            get { return _postalc; }
            set { _postalc = value; }
        }
        public static ANetApiResponse Run(String ApiLoginID, String ApiTransactionKey, decimal amount)
        {
            //Console.WriteLine("Charge Credit Card Sample");
            DataTable dt;



            //ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.SANDBOX;
            ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.PRODUCTION;

            // define the merchant information (authentication / transaction id)
            ApiOperationBase<ANetApiRequest, ANetApiResponse>.MerchantAuthentication = new merchantAuthenticationType()
            {
                name = ApiLoginID,
               ItemElementName = ItemChoiceType.transactionKey,
                Item = ApiTransactionKey,
            };


            var creditCard = new creditCardType
            {
                cardNumber = _cCTag,
                expirationDate = _Month + _Year.Substring(2, 2),
                cardCode = _CV

                //cardNumber = "4111111111111111",
                //expirationDate = "1028",
                //cardCode = "123"
            };

            var billingAddress = new customerAddressType
            {
                firstName = _cardHolder.Substring(0, _cardHolder.IndexOf(" ")),


                lastName = _cardHolder.Substring(_cardHolder.IndexOf(" ") + 1, _cardHolder.Length - _cardHolder.IndexOf(" ") - 1),
                address = _addr,
                city = _city,
                zip = _postalc

                //firstName = "John",
                //lastName = "Doe",
                //address = "123 My St",
                //city = "OurTown",
                //zip = "98004"
            };

            //standard api call to retrieve response
            var paymentType = new paymentType { Item = creditCard };

            // Add line Items
            //var lineItems = new lineItemType[2];
            //lineItems[0] = new lineItemType { itemId = "1", name = "t-shirt", quantity = 2, unitPrice = new Decimal(15.00) };
            //lineItems[1] = new lineItemType { itemId = "2", name = "snowboard", quantity = 1, unitPrice = new Decimal(450.00) };


            dt = TonFormApps.SQL.Run(" select b.invdesc, b.shortname,a.amount, 1 as unit from Formdata a LEFT JOIN Inventory b on b.invid = a.inv_id_fk where a.id =  @dID", TonFormApps.Core.xID); // Tax Certificate request
            var lineItems = new lineItemType[dt.Rows.Count];
            if (dt.Rows.Count > 0)
            {
                for (int r = 0; r < dt.Rows.Count; r++)

                {
                    lineItems[r] = new lineItemType { itemId = r + 1.ToString(), name = dt.Rows[r]["invdesc"].ToString().Substring(0,31), quantity = 1, unitPrice = Convert.ToDecimal(dt.Rows[r]["amount"]) };

                }


            }



            var transactionRequest = new transactionRequestType
            {
                transactionType = transactionTypeEnum.authCaptureTransaction.ToString(),    // charge the card

                amount = amount,
                payment = paymentType,
                billTo = billingAddress,
                lineItems = lineItems
            };

            var request = new createTransactionRequest { transactionRequest = transactionRequest };

            // instantiate the controller that will call the service
            var controller = new createTransactionController(request);
            controller.Execute();

            ANetApiResponse errorResponse = controller.GetErrorResponse();

            // get the response from the service (errors contained if any)
            var response = controller.GetApiResponse();

            //foreach (var message in errorResponse.messages.message)
            //{
            //    string code = message.code;
            //    string text = message.text;
            //}
            // validate response
            if (response != null)
            {
                if (response.messages.resultCode == messageTypeEnum.Ok)
                {
                    if (response.transactionResponse.messages != null)
                    {
                        _xStatusResult = true;
                        _xTransResult =  response.transactionResponse.transId;
                        //Console.WriteLine("Successfully created transaction with Transaction ID: " + response.transactionResponse.transId);
                        //Console.WriteLine("Response Code: " + response.transactionResponse.responseCode);
                        //Console.WriteLine("Message Code: " + response.transactionResponse.messages[0].code);
                        //Console.WriteLine("Description: " + response.transactionResponse.messages[0].description);
                        //Console.WriteLine("Success, Auth Code : " + response.transactionResponse.authCode);
                    }
                    else
                    {
                        _xStatusResult = false;
                        //Console.WriteLine("Failed Transaction.");
                        _xTransResult = "Failed Transaction";
                        if (response.transactionResponse.errors != null)
                        {
                            //Console.WriteLine("Error Code: " + response.transactionResponse.errors[0].errorCode);
                            //Console.WriteLine("Error message: " + response.transactionResponse.errors[0].errorText);
                            _xTransResult = response.transactionResponse.errors[0].errorText;
                        }
                    }
                }
                else
                {
                    _xStatusResult = false;
    
                    //Console.WriteLine("Failed Transaction.");
                    if (response.transactionResponse != null && response.transactionResponse.errors != null)
                    {
                        //Console.WriteLine("Error Code: " + response.transactionResponse.errors[0].errorCode);
                        //Console.WriteLine("Error message: " + response.transactionResponse.errors[0].errorText);
                        _xTransResult = response.transactionResponse.errors[0].errorText;
                    }
                    else
                    {
                        //Console.WriteLine("Error Code: " + response.messages.message[0].code);
                        //Console.WriteLine("Error message: " + response.messages.message[0].text);
                        _xTransResult =  response.messages.message[0].text;
                    }
                }
            }
            else
            {
                _xStatusResult = false;
                _xTransResult = "Null response";
                //Console.WriteLine("Null Response.");
            }

            return response;
        }


       
    }


   
}