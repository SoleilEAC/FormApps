﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TonFormApps
{
    public partial class LicenceTracker : System.Web.UI.Page
    {
        int cnt = 0;
        static DataTable dtLicence;

       
        protected void BtnSubmit_Click(object sender, EventArgs e)
        {
            string strBus, strLic = "";
            int numLoc, strLen = 0;
            Boolean ccont = true;
            cnt = 0;

            Label1.Text = "";
            Label2.Text = "";

            LblCnt.Text = cnt.ToString();
            strBus = TextBox4.Text;
            strLic = TextBox1.Text;

            // Empty search
            if (strBus.Length == 0 & strLic.Length == 0)
            {
                Label2.Text = "Enter some search criteria to find a licence.";
                ccont = false;
            }

            if (strBus.Length > 0)
            {
                if (strBus.Length < 3)
                {
                    Label2.Text = "You must enter at least three characters to search on Business Name.";
                    ccont = false;
                }
            }
            if (strLic.Length > 0)
            {
                if (strLic.Length < 12) //BL2021-00111
                {
                    Label2.Text = "You must enter the complete Licence Number, in the format BL9999-99999";
                    ccont = false;
                }
            }


            if (ccont)
            {

                // Validate if Licence Number has - character then remove it.
                if (strLic.Length > 0)

                    if (strLic.ToLower().IndexOf('-') != -1)
                    {
                        numLoc = strLic.ToLower().IndexOf('-');
                        strLen = strLic.Length;
                        strLic = strLic.Substring(0, numLoc) + strLic.Substring(numLoc + 1, (strLen - numLoc) - 1);

                    }

                if (strBus.Length > 0 & strLic.Length > 0)
                {

                    dtLicence = SQL.Run("Select substring(LicenceNumber,1,6)+'-'+substring(LicenceNumber,7,5) as LicenceNumber,[BusinessName],[Classification],[Status] from LicenceTracker where BusinessName like @BusinessName and LicenceNumber= @LicenceNumber", strBus + "%", strLic);

                    if (dtLicence.Rows.Count > 0)
                        TransGrid();
                    else
                        Label2.Text = "No licences have been found matching search criteria.";

                }

                if (strBus.Length > 0 & strLic.Length == 0)
                {

                    dtLicence = SQL.Run("Select substring(LicenceNumber,1,6)+'-'+substring(LicenceNumber,7,5) as LicenceNumber,[BusinessName],[Classification],[Status] from LicenceTracker where BusinessName like @BusinessName", "%" + strBus + "%");
                    if (dtLicence.Rows.Count > 0)
                        TransGrid();
                    else
                        Label2.Text = "No licences have been found matching search criteria.";

                }

                if (strBus.Length == 0 & strLic.Length > 0)
                {

                    dtLicence = SQL.Run("Select substring(LicenceNumber,1,6)+'-'+substring(LicenceNumber,7,5) as LicenceNumber,[BusinessName],[Classification],[Status] from LicenceTracker where LicenceNumber= @LicenceNumber", strLic);
                    if (dtLicence.Rows.Count > 0)
                        TransGrid();
                    else
                        Label2.Text = "No licences have been found matching search criteria.";

                }
            }
            log(strBus, strLic);

        }

        protected void BtnReset_Click(object sender, EventArgs e)
        {
            cnt = 0;
            LblCnt.Text = cnt.ToString();
            TextBox4.Text = "";
            TextBox1.Text = "";
            Label1.Text = "";
            Label2.Text = "";
            BtnPrev.Enabled = false;
            BtnPrev.Visible = false;
            BtnNext.Enabled = false;
            BtnNext.Visible = false;
        }

        public void log(string bn, string bl)
        {
            string ipaddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

            if (ipaddress == "" || ipaddress == null)
                ipaddress = Request.ServerVariables["REMOTE_ADDR"];

            SQL.Run("insert into log values ( @TIMESTAMP,@IP, @BN,@LN)", DateTime.Now, ipaddress, bn, bl);
        }

        private void TransGrid()
        {
            cnt = int.Parse(LblCnt.Text);
            int cntLocal = 0;

            Label1.Text = "<table id =\"t01\" class=\"table-Border\"> <tr class=\"table-Border\"><th class=\"table-Border\">Licence Number</th><th class=\"table-Border\">Business Name</th><th class=\"table-Border\">Classification</th><th class=\"table-Border\">Status</th></tr>";
            int contador = 0;
            if (cnt == 0)
            {
                //Disable Previous
                BtnPrev.Enabled = false;
                BtnPrev.Visible = true;
            }
            else
            {
                //Enable Previous
                BtnPrev.Enabled = true;
                BtnPrev.Visible = true;
            }

            for (int i = cnt; i < dtLicence.Rows.Count & contador < 10; i++)
            {
                contador = contador + 1;
                Label1.Text = Label1.Text
                          + "<tr class=\"table-Border\"><td class=\"table-Border\">" + dtLicence.Rows[i]["LicenceNumber"].ToString() + "</td><td class=\"table-Border\">" + dtLicence.Rows[i]["BusinessName"].ToString() + "</td><td class=\"table-Border\">" + dtLicence.Rows[i]["Classification"].ToString() + "</td><td class=\"table-Border\">" + dtLicence.Rows[i]["Status"].ToString() + "</td></tr>";
                cntLocal = i + 1;
                LblCnt.Text = cntLocal.ToString();
            }
            Label1.Text = Label1.Text + "</table> ";
            cnt = int.Parse(LblCnt.Text);

            // There are more rows to show
            if (dtLicence.Rows.Count > cnt)
            {
                BtnNext.Enabled = true;
                BtnNext.Visible = true;
            }
            else
            {
                BtnNext.Enabled = false;
                BtnNext.Visible = true;
            }

        }

        protected void BtnNext_Click(object sender, EventArgs e)
        {
            TransGrid();
        }

        protected void BtnPrev_Click(object sender, EventArgs e)
        {
            string strtemp = "1" + LblCnt.Text.Substring(1, 1);
            int cntLocal = 0;

            if (LblCnt.Text.Substring(1, 1) == "0")
                cntLocal = int.Parse(LblCnt.Text) - 20;
            else
                cntLocal = int.Parse(LblCnt.Text) - int.Parse(strtemp);

            LblCnt.Text = cntLocal.ToString();


            TransGrid();
        }



    }
}